import React, { useReducer, useEffect } from 'react'
import axios from 'axios'
import {DataTable} from 'primereact/datatable';
import {Column} from 'primereact/column';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
// import {InputText} from 'primereact/inputtext';
import { Button as Primebutton} from 'primereact/components/button/Button';
import './shippingTable.css';

const initialState = {
	loading: true,
	error: '',
	post: []
}
const payload = {
	cargo:{},
	service:{}
}
let paginatorLeft = <Primebutton icon="pi pi-refresh"/>;
let paginatorRight = <Primebutton icon="pi pi-cloud-upload"/>;
// let header = <div style={{'textAlign':'left'}}>
// 				<i className="pi pi-search" style={{margin:'4px 4px 0 0'}}></i>
// 				<InputText type="search" onInput={(e) => setval(e)} placeholder="Global Search" size="50"/>
// 			</div>

const reducer = (state, action) => {
	switch (action.type) {
		case 'FETCH_SUCCESS':
			return {
				loading: false,
				post: action.payload,
				error: ''
			}
		case 'FETCH_ERROR':
			return {
				loading: false,
				post: [],
				error: 'Something went wrong!'
			}
		default:
			return state
	}
}
const handleSubmit = (event) =>{
	event.preventDefault();
	payload.id = event.target.elements.id.value;
	payload.name = event.target.elements.name.value;
	payload.mode = event.target.elements.mode.value;
	payload.type = event.target.elements.type.value;
	payload.destination = event.target.elements.destination.value;
	payload.origin = event.target.elements.origin.value;
	payload.total = event.target.elements.total.value;
	payload.status = event.target.elements.status.value;
	payload.cargo.volume = event.target.elements.Cargovolume.value;
	payload.cargo.type = event.target.elements.Cargotype.value;
	payload.cargo.description = event.target.elements.Cargodescription.value;
	payload.service.servicestype = event.target.elements.servicestype.value;
	payload.service.value = event.target.elements.servicesvalue.value;
	console.log(payload);
}
const edit = (e) => {
	console.log(e.value);
}
function DataFetchingTwo() {
	const [state, dispatch] = useReducer(reducer, initialState)
	
	useEffect(() => {
		
		axios
			.get(`http://localhost:3000/shipments`)
			.then(response => {
				dispatch({ type: 'FETCH_SUCCESS', payload: response.data })
			})
			.catch(error => {
				dispatch({ type: 'FETCH_ERROR' })
			})
	}, [])
	return (
        <div>
		<div className="container">
		<form  className="needs-validation" onSubmit={handleSubmit}>
		<div className="row  d-flex">
			<div className="form-group px-4">
				<label htmlFor="id">ID:</label>
				<input type="text" className="form-control" id="id" placeholder="Enter ID" name="id" required></input>
				<div className="invalid-feedback">
        			The ID is required!
      			</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="name">Name:</label>
				<input type="text" className="form-control" id="name" placeholder="Enter Name" name="name" required></input>
				<div className="invalid-feedback">
        			The Name is required!
      			</div>
			</div>
			{/* <div className="form-group px-4">
				<label htmlFor="corgos">Corgos:</label>
				<select className="form-control" id="sel1" name="corgos">
					<option>1</option>
					<option>2</option>
					<option>3</option>
					<option>4</option>
				</select>
				<div className="invalid-feedback">
        			The Corgos is required!
      			</div>
			</div> */}
			<div className="form-group px-4">
				<label htmlFor="mode">Mode:</label>
				<input type="text" className="form-control" id="mode" placeholder="Enter mode" name="mode" required></input>
				<div className="invalid-feedback">
        			The Mode is required!
      			</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="type">Type:</label>
				<input type="text" className="form-control" id="type" placeholder="Enter type" name="type" required></input>
				<div className="invalid-feedback">
        			The type is required!
      			</div>
			</div>
		</div>
		<div className="row  d-flex">
			<div className="form-group px-4">
				<label htmlFor="destination">Destination:</label>
				<input type="text" className="form-control" id="destination" placeholder="Enter destination" name="destination" required></input>
				<div className="invalid-feedback">
        			The destination is required!
      			</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="origin">Origin:</label>
				<input type="text" className="form-control" id="origin" placeholder="Enter Origin" name="origin" required></input>
				<div className="invalid-feedback">
        			The Origin is required!
      			</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="total">Total:</label>
				<input type="text" className="form-control" id="total" placeholder="Enter Total" name="total" required></input>
				<div className="invalid-feedback">
        			The Total is required!
      			</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="status">Status:</label>
				<input type="text" className="form-control" id="status" placeholder="Enter status" name="status" required></input>
				<div className="invalid-feedback">
        			The status is required!
      			</div>
			</div>
		</div>
		<div className="row  d-flex">
			<div className="form-group px-4">
				<label htmlFor="Cargo-Type">Cargo Type:</label>
				<input type="text" className="form-control" id="Cargo-Type" placeholder="Enter Cargo Type" name="Cargotype" required></input>
				<div className="invalid-feedback">
					The Cargo Type is required!
				</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="Cargo-description">Cargo Description:</label>
				<input type="text" className="form-control" id="Cargo-description" placeholder="Enter Cargo description" name="Cargodescription" required></input>
				<div className="invalid-feedback">
					The Cargo Description is required!
				</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="Cargo-volume">Cargo volume:</label>
				<input type="text" className="form-control" id="Cargo-volume" placeholder="Enter Cargo volume" name="Cargovolume" required></input>
				<div className="invalid-feedback">
					The Cargo volume is required!
				</div>
			</div>
		</div>
		<div className="row  d-flex">
			<div className="form-group px-4">
				<label htmlFor="services-Type">Services Type:</label>
				<input type="text" className="form-control" id="services-Type" placeholder="Enter services Type" name="servicestype" required></input>
				<div className="invalid-feedback">
					The Services Type is required!
				</div>
			</div>
			<div className="form-group px-4">
				<label htmlFor="services-value">Services value:</label>
				<input type="text" className="form-control" id="services-value" placeholder="Enter services value" name="servicesvalue"></input>
				<div className="invalid-feedback">
					The Services value is required!
				</div>
			</div>
		</div>
			<button type="submit" className="btn btn-primary">Submit</button>
		</form>
		</div>
		<div className="content-section implementation">
			{/* {state.loading ? 'Loading' : state.post.title}
			{state.error ? state.error : null} */}
            <DataTable value={state.post} selectionMode="single"
                selection={state.post.id} onSelectionChange={e => edit(e)} emptyMessage="No records found" resizabColumns={true} scrollable={true} scrollHeight="400px" paginator={true} paginatorLeft={paginatorLeft} paginatorRight={paginatorRight} rows={20} rowsPerPageOptions={[5,10,20]}>
                <Column field="id" header="ID"  sortable={true}/>
                <Column field="name" header="Name" sortable={true}/>
                <Column field="cargo.length" header="No. of Cargos"/>
                <Column field="mode" header="Mode"/>
                <Column field="type" header="Type"/>
                <Column field="destination" header="Destination"/>
                <Column field="origin" header="Origin"/>
                <Column field="services.length" header="No. of Services"/>
                <Column field="total" header="Total"/>
                <Column field="status" header="Status"/>
                <Column field="userId" header="User-Id"/>
            </DataTable>
		</div>
    </div>
	)
}

export default DataFetchingTwo