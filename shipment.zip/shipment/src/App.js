import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import DataFetchingTwo from "./components/shipping-Table/shipping-table";
function App() {
  return (
    <div className="App">
      <DataFetchingTwo/>
    </div>
  );
}

export default App;
